const express = require('express');
const router = express.Router();
const Event = require('../models/Event');

// GET /events — public list
router.get('/', async (req, res) => {
  try {
    const events = await Event.find({ status: { $ne: 'cancelled' } }).sort({ date: 1 });
    res.render('events/list', { title: 'Events — EventFlow', events });
  } catch (err) { next(err); }
});

// GET /events/:id
router.get('/:id', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id).populate('createdBy', 'name');
    if (!event) return res.redirect('/events');
    res.render('events/detail', { title: event.title + ' — EventFlow', event });
  } catch (err) { next(err); }
});

module.exports = router;
