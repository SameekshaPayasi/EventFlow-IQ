const express = require('express');
const router = express.Router();
const Event = require('../models/Event');

router.get('/', async (req, res) => {
  try {
    const events = await Event.find({ status: { $ne: 'cancelled' } })
      .sort({ date: 1 })
      .limit(6)
      .populate('createdBy', 'name');

    if (req.session.user) {
      if (req.session.user.role === 'admin') return res.redirect('/admin/dashboard');
      return res.redirect('/student/dashboard');
    }

    res.render('index', { title: 'EventFlow — Campus Event Platform', events });
  } catch (err) {
    next(err);
  }
});

module.exports = router;
