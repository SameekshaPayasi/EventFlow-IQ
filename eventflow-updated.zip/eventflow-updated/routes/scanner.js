const express = require('express');
const router = express.Router();
const Registration = require('../models/Registration');
const Event = require('../models/Event');
const { isAdmin } = require('../middleware/auth');

// POST /scan/verify — API endpoint called by QR scanner
router.post('/verify', isAdmin, async (req, res) => {
  try {
    const { qrPayload, eventId } = req.body;

    let parsed;
    try {
      parsed = JSON.parse(qrPayload);
    } catch {
      return res.json({ success: false, message: 'Invalid QR code format' });
    }

    const { ticketId, userId, eventId: qrEventId } = parsed;

    // Check event matches (optional strict check)
    if (eventId && qrEventId && qrEventId !== eventId) {
      return res.json({ success: false, message: 'This ticket is for a different event' });
    }

    const reg = await Registration.findOne({ ticketId })
      .populate('user', 'name email rollNo department')
      .populate('event', 'title date venue');

    if (!reg) {
      return res.json({ success: false, message: 'Ticket not found in system' });
    }

    if (reg.status === 'attended') {
      return res.json({
        success: false,
        message: `Already checked in at ${reg.attendedAt?.toLocaleTimeString()}`,
        attendee: { name: reg.user.name, ticketId: reg.ticketId }
      });
    }

    if (reg.status === 'cancelled') {
      return res.json({ success: false, message: 'This registration was cancelled' });
    }

    // Mark as attended
    reg.status      = 'attended';
    reg.attendedAt  = new Date();
    reg.scannedBy   = req.session.user._id;
    reg.certificateIssued = true;
    await reg.save();

    // Increment attended count on event
    await Event.findByIdAndUpdate(reg.event._id, { $inc: { attendedCount: 1 } });

    res.json({
      success: true,
      message: 'Check-in successful! ✓',
      attendee: {
        name:       reg.user.name,
        email:      reg.user.email,
        rollNo:     reg.user.rollNo,
        department: reg.user.department,
        ticketId:   reg.ticketId,
        event:      reg.event.title,
        checkedIn:  reg.attendedAt.toLocaleTimeString()
      }
    });

  } catch (err) {
    console.error(err);
    res.json({ success: false, message: 'Server error during verification' });
  }
});

module.exports = router;
