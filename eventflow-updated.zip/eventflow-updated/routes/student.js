const express = require('express');
const router = express.Router();
const Event = require('../models/Event');
const Registration = require('../models/Registration');
const QRCode = require('qrcode');
const { isLoggedIn } = require('../middleware/auth');

router.use(isLoggedIn);

// GET /student/dashboard
router.get('/dashboard', async (req, res) => {
  try {
    const myRegs = await Registration.find({ user: req.session.user._id })
      .populate('event')
      .sort({ registeredAt: -1 });

    const upcomingEvents = await Event.find({ status: 'upcoming', _id: { $nin: myRegs.map(r => r.event?._id) } })
      .sort({ date: 1 }).limit(6);

    const stats = {
      registered: myRegs.length,
      attended:   myRegs.filter(r => r.status === 'attended').length,
      certificates: myRegs.filter(r => r.certificateIssued).length,
      upcoming:   myRegs.filter(r => r.event?.status === 'upcoming').length
    };

    res.render('student/dashboard', {
      title: 'My Dashboard — EventFlow',
      myRegs, upcomingEvents, stats
    });
  } catch (err) { console.error(err); next(err); }
});

// GET /student/events — browse all events
router.get('/events', async (req, res) => {
  try {
    const { category, status, search } = req.query;
    let query = {};
    if (category) query.category = category;
    if (status)   query.status   = status;
    if (search)   query.title    = { $regex: search, $options: 'i' };

    const events = await Event.find(query).sort({ date: 1 });

    // Get user registrations to show which ones they're registered for
    const myRegs = await Registration.find({ user: req.session.user._id }).select('event');
    const registeredIds = myRegs.map(r => r.event.toString());

    res.render('student/events', {
      title: 'Browse Events — EventFlow',
      events, registeredIds, category, status, search
    });
  } catch (err) { next(err); }
});

// GET /student/events/:id — event detail
router.get('/events/:id', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id).populate('createdBy', 'name');
    if (!event) { req.flash('error', 'Event not found'); return res.redirect('/student/events'); }

    const reg = await Registration.findOne({ user: req.session.user._id, event: event._id });

    res.render('student/event-detail', {
      title: event.title + ' — EventFlow',
      event, registration: reg
    });
  } catch (err) { next(err); }
});

// POST /student/events/:id/register
router.post('/events/:id/register', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) { req.flash('error', 'Event not found'); return res.redirect('/student/events'); }

    // Check capacity
    if (event.registeredCount >= event.capacity) {
      req.flash('error', 'This event is full');
      return res.redirect(`/student/events/${event._id}`);
    }

    // Check deadline
    if (event.registrationDeadline && new Date() > new Date(event.registrationDeadline)) {
      req.flash('error', 'Registration deadline has passed');
      return res.redirect(`/student/events/${event._id}`);
    }

    // Check duplicate
    const existing = await Registration.findOne({ user: req.session.user._id, event: event._id });
    if (existing) {
      req.flash('info', 'You are already registered for this event');
      return res.redirect(`/student/ticket/${existing._id}`);
    }

    // Create registration
    const reg = new Registration({
      user:  req.session.user._id,
      event: event._id
    });

    // Generate QR payload
    reg.qrPayload = JSON.stringify({ ticketId: reg.ticketId, userId: req.session.user._id, eventId: event._id });

    // Generate QR image (base64)
    reg.qrData = await QRCode.toDataURL(reg.qrPayload, {
      width: 200,
      margin: 2,
      color: { dark: '#1a1a2e', light: '#ffffff' }
    });

    await reg.save();

    // Increment event count
    await Event.findByIdAndUpdate(event._id, { $inc: { registeredCount: 1 } });

    req.flash('success', `Successfully registered for "${event.title}"! Your ticket is ready.`);
    res.redirect(`/student/ticket/${reg._id}`);
  } catch (err) {
    console.error(err);
    req.flash('error', 'Registration failed. Please try again.');
    res.redirect(`/student/events/${req.params.id}`);
  }
});

// POST /student/events/:id/cancel
router.post('/events/:id/cancel', async (req, res) => {
  try {
    const reg = await Registration.findOne({ user: req.session.user._id, event: req.params.id });
    if (!reg) { req.flash('error', 'Registration not found'); return res.redirect('/student/dashboard'); }
    if (reg.status === 'attended') { req.flash('error', 'Cannot cancel — you already attended'); return res.redirect('/student/dashboard'); }

    await Registration.findByIdAndDelete(reg._id);
    await Event.findByIdAndUpdate(req.params.id, { $inc: { registeredCount: -1 } });

    req.flash('success', 'Registration cancelled');
    res.redirect('/student/dashboard');
  } catch (err) {
    req.flash('error', 'Failed to cancel');
    res.redirect('/student/dashboard');
  }
});

// GET /student/ticket/:id
router.get('/ticket/:id', async (req, res) => {
  try {
    const reg = await Registration.findById(req.params.id)
      .populate('user', 'name email rollNo department')
      .populate('event');

    if (!reg) { req.flash('error', 'Ticket not found'); return res.redirect('/student/dashboard'); }
    if (reg.user._id.toString() !== req.session.user._id.toString()) {
      req.flash('error', 'Access denied');
      return res.redirect('/student/dashboard');
    }

    res.render('student/ticket', { title: 'My Ticket — EventFlow', registration: reg });
  } catch (err) { next(err); }
});

// GET /student/my-tickets
router.get('/my-tickets', async (req, res) => {
  try {
    const registrations = await Registration.find({ user: req.session.user._id })
      .populate('event')
      .sort({ registeredAt: -1 });

    res.render('student/my-tickets', { title: 'My Tickets — EventFlow', registrations });
  } catch (err) { next(err); }
});

// GET /student/profile
router.get('/profile', async (req, res) => {
  const User = require('../models/User');
  try {
    const user = await User.findById(req.session.user._id);
    res.render('student/profile', { title: 'My Profile — EventFlow', user });
  } catch (err) { next(err); }
});

module.exports = router;
