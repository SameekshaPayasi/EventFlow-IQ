const express = require('express');
const router = express.Router();
const Event = require('../models/Event');
const User = require('../models/User');
const Registration = require('../models/Registration');
const { isAdmin } = require('../middleware/auth');

// All admin routes require admin role
router.use(isAdmin);

// GET /admin/dashboard
router.get('/dashboard', async (req, res) => {
  try {
    const [totalEvents, totalUsers, totalRegs, totalAttended] = await Promise.all([
      Event.countDocuments(),
      User.countDocuments({ role: 'student' }),
      Registration.countDocuments(),
      Registration.countDocuments({ status: 'attended' })
    ]);

    const upcomingEvents = await Event.find({ status: 'upcoming' })
      .sort({ date: 1 }).limit(5);
    const recentRegs = await Registration.find()
      .sort({ registeredAt: -1 }).limit(8)
      .populate('user', 'name email')
      .populate('event', 'title date');

    res.render('admin/dashboard', {
      title: 'Admin Dashboard — EventFlow',
      stats: { totalEvents, totalUsers, totalRegs, totalAttended },
      upcomingEvents,
      recentRegs
    });
  } catch (err) { next(err); }
});

// GET /admin/events
router.get('/events', async (req, res) => {
  try {
    const { status, search } = req.query;
    let query = {};
    if (status) query.status = status;
    if (search) query.title = { $regex: search, $options: 'i' };

    const events = await Event.find(query).sort({ date: -1 })
      .populate('createdBy', 'name');

    res.render('admin/events', {
      title: 'Manage Events — EventFlow',
      events, status, search
    });
  } catch (err) { next(err); }
});

// GET /admin/events/new
router.get('/events/new', (req, res) => {
  res.render('admin/event-form', {
    title: 'Create Event — EventFlow',
    event: null,
    isEdit: false
  });
});

// POST /admin/events
router.post('/events', async (req, res) => {
  try {
    const { title, description, date, endDate, time, venue, capacity, category, registrationDeadline, tags, bannerColor } = req.body;

    const event = await Event.create({
      title, description, date, endDate, time, venue,
      capacity: parseInt(capacity),
      category, registrationDeadline,
      tags: tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [],
      bannerColor: bannerColor || '#1a1a2e',
      createdBy: req.session.user._id
    });

    req.flash('success', `Event "${event.title}" created successfully!`);
    res.redirect('/admin/events');
  } catch (err) {
    console.error(err);
    req.flash('error', 'Failed to create event: ' + err.message);
    res.redirect('/admin/events/new');
  }
});

// GET /admin/events/:id/edit
router.get('/events/:id/edit', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) { req.flash('error', 'Event not found'); return res.redirect('/admin/events'); }
    res.render('admin/event-form', {
      title: 'Edit Event — EventFlow',
      event, isEdit: true
    });
  } catch (err) { next(err); }
});

// PUT /admin/events/:id
router.put('/events/:id', async (req, res) => {
  try {
    const { title, description, date, endDate, time, venue, capacity, category, status, registrationDeadline, tags, bannerColor } = req.body;
    await Event.findByIdAndUpdate(req.params.id, {
      title, description, date, endDate, time, venue,
      capacity: parseInt(capacity),
      category, status, registrationDeadline,
      tags: tags ? tags.split(',').map(t => t.trim()).filter(Boolean) : [],
      bannerColor: bannerColor || '#1a1a2e'
    });
    req.flash('success', 'Event updated successfully!');
    res.redirect('/admin/events');
  } catch (err) {
    console.error(err);
    req.flash('error', 'Update failed');
    res.redirect(`/admin/events/${req.params.id}/edit`);
  }
});

// DELETE /admin/events/:id
router.delete('/events/:id', async (req, res) => {
  try {
    await Event.findByIdAndDelete(req.params.id);
    await Registration.deleteMany({ event: req.params.id });
    req.flash('success', 'Event deleted');
    res.redirect('/admin/events');
  } catch (err) {
    req.flash('error', 'Delete failed');
    res.redirect('/admin/events');
  }
});

// GET /admin/events/:id/registrations
router.get('/events/:id/registrations', async (req, res) => {
  try {
    const event = await Event.findById(req.params.id);
    if (!event) { req.flash('error', 'Event not found'); return res.redirect('/admin/events'); }

    const registrations = await Registration.find({ event: req.params.id })
      .populate('user', 'name email rollNo department')
      .sort({ registeredAt: -1 });

    res.render('admin/registrations', {
      title: `Registrations — ${event.title}`,
      event, registrations
    });
  } catch (err) { next(err); }
});

// GET /admin/users
router.get('/users', async (req, res) => {
  try {
    const users = await User.find({ role: 'student' }).sort({ createdAt: -1 });
    res.render('admin/users', { title: 'Students — EventFlow', users });
  } catch (err) { next(err); }
});

// GET /admin/scanner/:eventId
router.get('/scanner/:eventId', async (req, res) => {
  try {
    const event = await Event.findById(req.params.eventId);
    if (!event) { req.flash('error', 'Event not found'); return res.redirect('/admin/events'); }
    res.render('admin/scanner', { title: `Scanner — ${event.title}`, event });
  } catch (err) { next(err); }
});

module.exports = router;
