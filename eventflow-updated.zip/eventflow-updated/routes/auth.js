const express = require('express');
const router = express.Router();
const User = require('../models/User');
const { isGuest } = require('../middleware/auth');

// GET /auth/login
router.get('/login', isGuest, (req, res) => {
  res.render('auth/login', { title: 'Sign In — EventFlow' });
});

// POST /auth/login
router.post('/login', isGuest, async (req, res) => {
  try {
    const { email, password } = req.body;

    if (!email || !password) {
      req.flash('error', 'Please fill in all fields');
      return res.redirect('/auth/login');
    }

    const user = await User.findOne({ email: email.toLowerCase() });
    if (!user) {
      req.flash('error', 'Invalid email or password');
      return res.redirect('/auth/login');
    }

    const isMatch = await user.comparePassword(password);
    if (!isMatch) {
      req.flash('error', 'Invalid email or password');
      return res.redirect('/auth/login');
    }

    req.session.user = {
      _id:        user._id,
      name:       user.name,
      email:      user.email,
      role:       user.role,
      department: user.department,
      rollNo:     user.rollNo,
      initials:   user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
    };

    req.flash('success', `Welcome back, ${user.name.split(' ')[0]}!`);

    if (user.role === 'admin') return res.redirect('/admin/dashboard');
    res.redirect('/student/dashboard');

  } catch (err) {
    console.error(err);
    req.flash('error', 'Something went wrong. Please try again.');
    res.redirect('/auth/login');
  }
});

// GET /auth/signup
router.get('/signup', isGuest, (req, res) => {
  res.render('auth/signup', { title: 'Create Account — EventFlow' });
});

// POST /auth/signup
router.post('/signup', isGuest, async (req, res) => {
  try {
    const { name, email, password, confirmPassword, rollNo, department, role } = req.body;

    // Validate
    if (!name || !email || !password) {
      req.flash('error', 'Please fill in all required fields');
      return res.redirect('/auth/signup');
    }

    if (password !== confirmPassword) {
      req.flash('error', 'Passwords do not match');
      return res.redirect('/auth/signup');
    }

    if (password.length < 6) {
      req.flash('error', 'Password must be at least 6 characters');
      return res.redirect('/auth/signup');
    }

    const existing = await User.findOne({ email: email.toLowerCase() });
    if (existing) {
      req.flash('error', 'An account with this email already exists');
      return res.redirect('/auth/signup');
    }

    // Only allow admin creation with a secret key (in production)
    const userRole = (role === 'admin' && req.body.adminKey === process.env.ADMIN_KEY) ? 'admin' : 'student';

    const user = await User.create({ name, email, password, rollNo, department, role: userRole });

    req.session.user = {
      _id:        user._id,
      name:       user.name,
      email:      user.email,
      role:       user.role,
      department: user.department,
      rollNo:     user.rollNo,
      initials:   user.name.split(' ').map(n => n[0]).join('').toUpperCase().slice(0, 2)
    };

    req.flash('success', `Welcome to EventFlow, ${user.name.split(' ')[0]}!`);
    res.redirect('/student/dashboard');

  } catch (err) {
    console.error(err);
    req.flash('error', 'Registration failed. Please try again.');
    res.redirect('/auth/signup');
  }
});

// POST /auth/logout
router.post('/logout', (req, res) => {
  req.session.destroy();
  res.redirect('/auth/login');
});

module.exports = router;
