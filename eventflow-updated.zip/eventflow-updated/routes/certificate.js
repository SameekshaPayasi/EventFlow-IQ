const express = require('express');
const router = express.Router();
const Registration = require('../models/Registration');
const { isLoggedIn } = require('../middleware/auth');

// GET /cert/:registrationId — view certificate
router.get('/:registrationId', isLoggedIn, async (req, res) => {
  try {
    const reg = await Registration.findById(req.params.registrationId)
      .populate('user', 'name email rollNo department')
      .populate('event');

    if (!reg) { req.flash('error', 'Certificate not found'); return res.redirect('/student/dashboard'); }

    // Only the ticket owner or admin can view
    const isOwner = reg.user._id.toString() === req.session.user._id.toString();
    const isAdmin = req.session.user.role === 'admin';
    if (!isOwner && !isAdmin) {
      req.flash('error', 'Access denied');
      return res.redirect('/student/dashboard');
    }

    if (reg.status !== 'attended') {
      req.flash('error', 'Certificate is only available after attending the event');
      return res.redirect('/student/dashboard');
    }

    res.render('certificate', {
      title: 'Certificate of Participation — EventFlow',
      registration: reg,
      layout: false
    });
  } catch (err) {
    console.error(err);
    req.flash('error', 'Could not load certificate');
    res.redirect('/student/dashboard');
  }
});

module.exports = router;
