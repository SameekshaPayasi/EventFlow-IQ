# 🎟️ EventFlow — Campus Event Management Platform

A full-stack Node.js web application for managing campus events with QR-based tickets, entry verification, and auto-generated certificates.

---

## 🚀 Quick Start

### 1. Install dependencies
```bash
npm install
```

### 2. Set up environment
```bash
cp .env.example .env
# Edit .env with your MongoDB URI and secret keys
```

### 3. Start MongoDB
```bash
# Make sure MongoDB is running
mongod
```

### 4. Seed demo data
```bash
node seed.js
```

### 5. Run the app
```bash
# Development (auto-restart)
npm run dev

# Production
npm start
```

Open **http://localhost:3000**

---

## 🔑 Demo Credentials

| Role    | Email                      | Password    |
|---------|----------------------------|-------------|
| Admin   | admin@eventflow.com        | admin123    |
| Student | student@eventflow.com      | student123  |
| Student | rahul@college.edu          | student123  |

---

## 📁 Project Structure

```
eventflow/
├── app.js                    # Express entry point
├── seed.js                   # Demo data seeder
├── .env.example              # Environment variables template
│
├── models/
│   ├── User.js               # User schema (bcrypt password)
│   ├── Event.js              # Event schema with virtuals
│   └── Registration.js       # Registration + ticket ID
│
├── routes/
│   ├── index.js              # Home / landing
│   ├── auth.js               # Login, signup, logout
│   ├── admin.js              # Admin dashboard & management
│   ├── student.js            # Student dashboard & registration
│   ├── events.js             # Public event listing
│   ├── scanner.js            # QR scan verification API
│   └── certificate.js        # Certificate viewer
│
├── middleware/
│   └── auth.js               # isLoggedIn, isAdmin, isGuest
│
├── views/
│   ├── index.ejs             # Landing page
│   ├── certificate.ejs       # Printable certificate
│   ├── 404.ejs / error.ejs
│   ├── partials/
│   │   ├── head.ejs
│   │   ├── navbar.ejs
│   │   ├── flash.ejs
│   │   ├── footer.ejs
│   │   ├── event-card.ejs
│   │   ├── admin-sidebar.ejs
│   │   └── student-sidebar.ejs
│   ├── auth/
│   │   ├── login.ejs
│   │   └── signup.ejs
│   ├── admin/
│   │   ├── dashboard.ejs
│   │   ├── events.ejs
│   │   ├── event-form.ejs
│   │   ├── registrations.ejs
│   │   ├── users.ejs
│   │   └── scanner.ejs
│   ├── student/
│   │   ├── dashboard.ejs
│   │   ├── events.ejs
│   │   ├── event-detail.ejs
│   │   ├── ticket.ejs
│   │   ├── my-tickets.ejs
│   │   └── profile.ejs
│   └── events/
│       ├── list.ejs          # Public event list
│       └── detail.ejs        # Public event detail
│
└── public/
    ├── css/style.css         # Full design system (1965 lines)
    └── js/main.js            # UI interactions & animations
```

---

## 🧩 Features

### 🔐 Authentication
- Signup & Login with bcrypt password hashing
- Session-based auth (7-day remember me)
- Role-based access: `admin` and `student`
- Guest-only routes (redirect logged-in users)

### 🎉 Event Management (Admin)
- Create, edit, delete events
- Set title, description, date, time, venue, capacity, category
- Custom banner color per event
- Tag system
- Filter by status or search by keyword

### 👥 Event Registration (Student)
- Browse all events with category/status filters
- Register for events (capacity check + duplicate prevention)
- Cancel registrations
- See real-time capacity bars

### 🎫 QR Code Tickets
- QR generated automatically on registration
- Contains `ticketId`, `userId`, `eventId`
- Printable ticket view
- Mobile-friendly

### 📱 QR Scanner (Entry System)
- Uses `html5-qrcode` library (camera-based)
- Manual fallback (type ticket ID)
- Real-time verification API at `POST /scan/verify`
- Prevents duplicate entry
- Live scan log with success/fail indicators

### 📜 Certificate Generation
- Available only for `status: attended` registrations
- Full-page printable design with corner ornaments
- Certificate ID = Ticket ID
- Print / Save as PDF via browser

### 📊 Admin Dashboard
- Stats: total events, students, registrations, attended
- Upcoming events list
- Recent registrations stream
- Per-event registration table with attendance tracking

---

## 🛠️ Tech Stack

| Layer      | Technology                        |
|------------|-----------------------------------|
| Backend    | Node.js + Express.js              |
| Database   | MongoDB + Mongoose                |
| Templating | EJS                               |
| Auth       | express-session + bcryptjs        |
| QR         | qrcode (generation) + html5-qrcode (scanning) |
| UI         | Custom CSS design system + Syne + DM Sans fonts |

---

## 🌐 Routes Reference

| Method | Route                              | Access  | Description               |
|--------|------------------------------------|---------|---------------------------|
| GET    | /                                  | Public  | Landing page              |
| GET    | /auth/login                        | Guest   | Login page                |
| POST   | /auth/login                        | Guest   | Process login             |
| GET    | /auth/signup                       | Guest   | Signup page               |
| POST   | /auth/signup                       | Guest   | Process signup            |
| POST   | /auth/logout                       | Auth    | Logout                    |
| GET    | /student/dashboard                 | Student | Student home              |
| GET    | /student/events                    | Student | Browse events             |
| GET    | /student/events/:id                | Student | Event detail              |
| POST   | /student/events/:id/register       | Student | Register for event        |
| POST   | /student/events/:id/cancel         | Student | Cancel registration       |
| GET    | /student/ticket/:id                | Student | View QR ticket            |
| GET    | /student/my-tickets                | Student | All my tickets            |
| GET    | /student/profile                   | Student | Profile page              |
| GET    | /admin/dashboard                   | Admin   | Admin home                |
| GET    | /admin/events                      | Admin   | Manage events             |
| GET    | /admin/events/new                  | Admin   | Create event form         |
| POST   | /admin/events                      | Admin   | Save new event            |
| GET    | /admin/events/:id/edit             | Admin   | Edit event form           |
| PUT    | /admin/events/:id                  | Admin   | Update event              |
| DELETE | /admin/events/:id                  | Admin   | Delete event              |
| GET    | /admin/events/:id/registrations    | Admin   | View registrations        |
| GET    | /admin/users                       | Admin   | View all students         |
| GET    | /admin/scanner/:eventId            | Admin   | QR Scanner page           |
| POST   | /scan/verify                       | Admin   | Verify QR (API)           |
| GET    | /cert/:registrationId              | Auth    | View certificate          |

---

## 🎨 Design System

The CSS (`public/css/style.css`) is a complete 1,965-line design system featuring:
- **Fonts**: Syne (display/headings) + DM Sans (body)
- **Colors**: Primary navy `#1a1a2e`, Accent red `#e94560`, Success teal `#2dca8c`
- **Components**: Cards, buttons, forms, badges, tables, modals, alerts, sidebar, navbar, tickets, certificates
- **Responsive**: Mobile-first, works on all screen sizes

---

## 📝 License

MIT — Free for educational and personal use.
