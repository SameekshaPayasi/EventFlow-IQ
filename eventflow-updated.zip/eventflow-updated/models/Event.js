const mongoose = require('mongoose');

const eventSchema = new mongoose.Schema({
  title: {
    type: String,
    required: [true, 'Title is required'],
    trim: true
  },
  description: {
    type: String,
    required: [true, 'Description is required']
  },
  date: {
    type: Date,
    required: [true, 'Date is required']
  },
  endDate: Date,
  time: String,
  venue: String,
  capacity: {
    type: Number,
    required: [true, 'Capacity is required'],
    min: 1
  },
  category: {
    type: String,
    enum: ['workshop', 'seminar', 'conference', 'hackathon', 'cultural', 'sports', 'other'],
    default: 'other'
  },
  status: {
    type: String,
    enum: ['upcoming', 'live', 'ended', 'cancelled'],
    default: 'upcoming'
  },
  registrationDeadline: Date,
  tags: [String],
  bannerColor: {
    type: String,
    default: '#1a1a2e'
  },
  createdBy: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User',
    required: true
  },
  registeredCount: {
    type: Number,
    default: 0
  },
  attendedCount: {
    type: Number,
    default: 0
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Virtual: spots left
eventSchema.virtual('spotsLeft').get(function() {
  return this.capacity - this.registeredCount;
});

// Virtual: is full
eventSchema.virtual('isFull').get(function() {
  return this.registeredCount >= this.capacity;
});

// Virtual: capacity percentage
eventSchema.virtual('capacityPercent').get(function() {
  return Math.min(100, Math.round((this.registeredCount / this.capacity) * 100));
});

// Auto-update status based on date
eventSchema.methods.updateStatus = function() {
  const now = new Date();
  if (this.status === 'cancelled') return;
  if (now < this.date) {
    this.status = 'upcoming';
  } else if (this.endDate && now <= this.endDate) {
    this.status = 'live';
  } else {
    this.status = 'ended';
  }
};

module.exports = mongoose.model('Event', eventSchema);
