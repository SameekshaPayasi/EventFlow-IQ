/* ============================================================
   EventFlow — Main JavaScript
   ============================================================ */

// ── Dropdown toggle ──
function toggleDropdown(trigger) {
  const menu = document.getElementById('userDropdown');
  if (!menu) return;
  menu.classList.toggle('show');
  trigger._open = menu.classList.contains('show');
}

document.addEventListener('click', function(e) {
  const menu = document.getElementById('userDropdown');
  if (!menu) return;
  if (!e.target.closest('.dropdown')) {
    menu.classList.remove('show');
  }
});

// ── Flash message auto-dismiss ──
document.addEventListener('DOMContentLoaded', function() {
  const flash = document.getElementById('flash-msg');
  if (flash) {
    setTimeout(() => {
      flash.style.transition = 'opacity 0.5s ease, transform 0.5s ease';
      flash.style.opacity = '0';
      flash.style.transform = 'translateY(-8px)';
      setTimeout(() => flash.remove(), 500);
    }, 5000);
  }

  // ── Active nav link highlight ──
  const path = window.location.pathname;
  document.querySelectorAll('.nav-link').forEach(link => {
    if (link.getAttribute('href') && path.startsWith(link.getAttribute('href')) && link.getAttribute('href') !== '/') {
      link.classList.add('active');
    }
  });

  document.querySelectorAll('.sidebar-link').forEach(link => {
    const href = link.getAttribute('href');
    if (href && path === href) {
      link.classList.add('active');
    }
  });

  // ── Confirm delete forms ──
  document.querySelectorAll('[data-confirm]').forEach(el => {
    el.addEventListener('click', function(e) {
      if (!confirm(this.dataset.confirm)) e.preventDefault();
    });
  });

  // ── Animate stat cards on scroll ──
  const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        entry.target.style.opacity = '1';
        entry.target.style.transform = 'translateY(0)';
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });

  document.querySelectorAll('.stat-card, .event-card, .card').forEach((el, i) => {
    el.style.opacity = '0';
    el.style.transform = 'translateY(16px)';
    el.style.transition = `opacity 0.4s ease ${i * 0.06}s, transform 0.4s ease ${i * 0.06}s`;
    observer.observe(el);
  });

  // ── Capacity bar animation ──
  document.querySelectorAll('.capacity-fill').forEach(bar => {
    const target = bar.style.width;
    bar.style.width = '0';
    setTimeout(() => { bar.style.width = target; }, 300);
  });

  // ── Table row hover highlight ──
  document.querySelectorAll('.table tbody tr').forEach(row => {
    row.style.cursor = 'default';
  });

  // ── Ticket print shortcut ──
  document.addEventListener('keydown', function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'p') {
      // Let browser handle print naturally
    }
  });

  // ── Form validation feedback ──
  document.querySelectorAll('.form-control[required]').forEach(input => {
    input.addEventListener('blur', function() {
      if (this.value.trim() === '') {
        this.classList.add('is-invalid');
        this.classList.remove('is-valid');
      } else {
        this.classList.remove('is-invalid');
        this.classList.add('is-valid');
      }
    });
    input.addEventListener('input', function() {
      if (this.value.trim() !== '') {
        this.classList.remove('is-invalid');
      }
    });
  });

  // ── Toast notifications ──
  initToast();
});

// ── Toast system ──
function initToast() {
  if (!document.getElementById('toast-container')) {
    const container = document.createElement('div');
    container.id = 'toast-container';
    container.style.cssText = `
      position: fixed;
      bottom: 1.5rem;
      right: 1.5rem;
      z-index: 9999;
      display: flex;
      flex-direction: column;
      gap: 0.5rem;
      pointer-events: none;
    `;
    document.body.appendChild(container);
  }
}

function showToast(message, type = 'success', duration = 3500) {
  const container = document.getElementById('toast-container');
  if (!container) return;

  const colors = {
    success: { bg: 'var(--success-soft)', color: '#0d6b4d', border: 'rgba(45,202,140,0.3)' },
    error:   { bg: 'var(--danger-soft)',  color: 'var(--accent)', border: 'rgba(233,69,96,0.3)' },
    info:    { bg: 'var(--info-soft)',    color: '#1260a0', border: 'rgba(79,172,254,0.3)' },
    warning: { bg: 'var(--warning-soft)', color: '#7a4d00', border: 'rgba(245,166,35,0.3)' }
  };

  const c = colors[type] || colors.success;
  const toast = document.createElement('div');
  toast.style.cssText = `
    background: ${c.bg};
    color: ${c.color};
    border: 1px solid ${c.border};
    border-radius: 10px;
    padding: 0.75rem 1.25rem;
    font-size: 0.88rem;
    font-weight: 500;
    max-width: 320px;
    pointer-events: all;
    opacity: 0;
    transform: translateX(16px);
    transition: opacity 0.3s ease, transform 0.3s ease;
    box-shadow: 0 4px 16px rgba(0,0,0,0.12);
  `;
  toast.textContent = message;
  container.appendChild(toast);

  requestAnimationFrame(() => {
    toast.style.opacity = '1';
    toast.style.transform = 'translateX(0)';
  });

  setTimeout(() => {
    toast.style.opacity = '0';
    toast.style.transform = 'translateX(16px)';
    setTimeout(() => toast.remove(), 300);
  }, duration);
}

// ── Sidebar mobile toggle ──
function toggleSidebar() {
  const sidebar = document.querySelector('.sidebar');
  if (!sidebar) return;
  sidebar.classList.toggle('open');
}

// ── Smooth scroll for anchor links ──
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
  anchor.addEventListener('click', function(e) {
    const target = document.querySelector(this.getAttribute('href'));
    if (target) {
      e.preventDefault();
      target.scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  });
});

// ── Number counter animation for stat cards ──
function animateCounter(el, target, duration = 1200) {
  const start = 0;
  const increment = target / (duration / 16);
  let current = start;
  const timer = setInterval(() => {
    current += increment;
    if (current >= target) {
      el.textContent = target.toLocaleString();
      clearInterval(timer);
    } else {
      el.textContent = Math.floor(current).toLocaleString();
    }
  }, 16);
}

// Run counter animation on stat values
document.addEventListener('DOMContentLoaded', function() {
  const statObserver = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
      if (entry.isIntersecting) {
        const el = entry.target;
        const val = parseInt(el.textContent.replace(/[^0-9]/g, ''));
        if (!isNaN(val) && val > 0) {
          animateCounter(el, val);
        }
        statObserver.unobserve(el);
      }
    });
  }, { threshold: 0.5 });

  document.querySelectorAll('.stat-value').forEach(el => {
    statObserver.observe(el);
  });
});

// ── Responsive table: add data-label on mobile ──
document.querySelectorAll('.table').forEach(table => {
  const headers = [...table.querySelectorAll('th')].map(th => th.textContent.trim());
  table.querySelectorAll('tbody tr').forEach(row => {
    [...row.querySelectorAll('td')].forEach((td, i) => {
      if (headers[i]) td.setAttribute('data-label', headers[i]);
    });
  });
});
