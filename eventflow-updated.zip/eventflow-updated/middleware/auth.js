// Ensure user is logged in
exports.isLoggedIn = (req, res, next) => {
  if (req.session.user) return next();
  req.flash('error', 'Please log in to continue');
  res.redirect('/auth/login');
};

// Ensure user is admin
exports.isAdmin = (req, res, next) => {
  if (req.session.user && req.session.user.role === 'admin') return next();
  req.flash('error', 'Admin access required');
  res.redirect('/');
};

// Ensure user is student
exports.isStudent = (req, res, next) => {
  if (req.session.user && req.session.user.role === 'student') return next();
  req.flash('error', 'Student access required');
  res.redirect('/');
};

// Already logged in → redirect to dashboard
exports.isGuest = (req, res, next) => {
  if (!req.session.user) return next();
  if (req.session.user.role === 'admin') return res.redirect('/admin/dashboard');
  return res.redirect('/student/dashboard');
};
