/**
 * EventFlow — Database Seed Script
 * Run: node seed.js
 * Creates demo admin, students, and events
 */

const mongoose = require('mongoose');
const User = require('./models/User');
const Event = require('./models/Event');
const Registration = require('./models/Registration');
const QRCode = require('qrcode');

mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/eventflow')
  .then(() => console.log('✅ Connected to MongoDB'))
  .catch(err => { console.error('❌ Connection failed:', err); process.exit(1); });

async function seed() {
  try {
    // Clear existing data
    await Promise.all([
      User.deleteMany({}),
      Event.deleteMany({}),
      Registration.deleteMany({})
    ]);
    console.log('🗑  Cleared existing data');

    // Create Admin
    const admin = await User.create({
      name:     'Admin User',
      email:    'admin@eventflow.com',
      password: 'admin123',
      role:     'admin',
      department: 'Administration'
    });
    console.log('👤 Admin created:', admin.email);

    // Create Students
    const students = await User.create([
      { name: 'Rahul Sharma',   email: 'rahul@college.edu',    password: 'student123', role: 'student', rollNo: '2021CS001', department: 'Computer Science' },
      { name: 'Priya Patel',    email: 'priya@college.edu',    password: 'student123', role: 'student', rollNo: '2021IT002', department: 'Information Technology' },
      { name: 'Arjun Singh',    email: 'arjun@college.edu',    password: 'student123', role: 'student', rollNo: '2021EC003', department: 'Electronics & Communication' },
      { name: 'Sneha Gupta',    email: 'sneha@college.edu',    password: 'student123', role: 'student', rollNo: '2021ME004', department: 'Mechanical Engineering' },
      { name: 'student@eventflow.com', email: 'student@eventflow.com', password: 'student123', role: 'student', rollNo: '2021CS005', department: 'Computer Science' }
    ]);
    console.log(`👥 ${students.length} students created`);

    // Create Events
    const now = new Date();
    const events = await Event.create([
      {
        title: 'National Hackathon 2025',
        description: 'A 36-hour coding marathon where teams build innovative solutions to real-world problems. Open to all departments. Prizes worth ₹1,00,000!',
        date: new Date(now.getTime() + 7 * 24 * 60 * 60 * 1000),
        endDate: new Date(now.getTime() + 8.5 * 24 * 60 * 60 * 1000),
        time: '9:00 AM – 9:00 PM (Day 1), 9:00 AM – 12:00 PM (Day 2)',
        venue: 'Main Auditorium & Computer Labs',
        capacity: 120,
        category: 'hackathon',
        status: 'upcoming',
        tags: ['Coding', 'Innovation', 'Prizes', 'Team Event'],
        bannerColor: '#0d2b6e',
        createdBy: admin._id,
        registeredCount: 45
      },
      {
        title: 'AI & Machine Learning Workshop',
        description: 'An intensive hands-on workshop covering the fundamentals of Artificial Intelligence and Machine Learning. Participants will build their first ML model using Python and TensorFlow.',
        date: new Date(now.getTime() + 3 * 24 * 60 * 60 * 1000),
        time: '10:00 AM – 4:00 PM',
        venue: 'Seminar Hall A, Block 3',
        capacity: 60,
        category: 'workshop',
        status: 'upcoming',
        tags: ['AI', 'Machine Learning', 'Python', 'TensorFlow'],
        bannerColor: '#1a2e0d',
        createdBy: admin._id,
        registeredCount: 52
      },
      {
        title: 'Tech Symposium 2025',
        description: 'Annual technical symposium featuring paper presentations, project expo, and keynote speakers from top tech companies. A platform to showcase your innovations.',
        date: new Date(now.getTime() + 14 * 24 * 60 * 60 * 1000),
        time: '9:00 AM – 6:00 PM',
        venue: 'Convention Center',
        capacity: 300,
        category: 'conference',
        status: 'upcoming',
        tags: ['Technology', 'Innovation', 'Networking', 'Research'],
        bannerColor: '#2e0d1a',
        createdBy: admin._id,
        registeredCount: 78
      },
      {
        title: 'Career Development Seminar',
        description: 'Industry professionals from top MNCs will guide students on career planning, resume building, and interview preparation. Placement tips and mock interviews included.',
        date: new Date(now.getTime() + 5 * 24 * 60 * 60 * 1000),
        time: '2:00 PM – 5:00 PM',
        venue: 'Seminar Hall B',
        capacity: 80,
        category: 'seminar',
        status: 'upcoming',
        tags: ['Career', 'Placement', 'Resume', 'Interview'],
        bannerColor: '#2e1a0d',
        createdBy: admin._id,
        registeredCount: 35
      },
      {
        title: 'Cultural Fest — Utsav 2025',
        description: 'The biggest cultural celebration of the year! Dance performances, music, drama, art exhibitions, food stalls, and much more. Come celebrate creativity!',
        date: new Date(now.getTime() + 20 * 24 * 60 * 60 * 1000),
        time: 'All Day — 10:00 AM onwards',
        venue: 'College Grounds',
        capacity: 500,
        category: 'cultural',
        status: 'upcoming',
        tags: ['Cultural', 'Dance', 'Music', 'Art', 'Food'],
        bannerColor: '#2e0d2e',
        createdBy: admin._id,
        registeredCount: 220
      },
      {
        title: 'Web Development Bootcamp',
        description: 'A 3-day intensive bootcamp covering HTML, CSS, JavaScript, Node.js and MongoDB. Build your first full-stack web application from scratch.',
        date: new Date(now.getTime() - 5 * 24 * 60 * 60 * 1000),
        endDate: new Date(now.getTime() - 3 * 24 * 60 * 60 * 1000),
        time: '9:00 AM – 5:00 PM',
        venue: 'Computer Lab 2',
        capacity: 40,
        category: 'workshop',
        status: 'ended',
        tags: ['Web Dev', 'JavaScript', 'Node.js', 'MongoDB'],
        bannerColor: '#0d2e2e',
        createdBy: admin._id,
        registeredCount: 40,
        attendedCount: 38
      }
    ]);
    console.log(`📅 ${events.length} events created`);

    // Create some registrations for students (for demo)
    const regsToCreate = [];
    for (let i = 0; i < Math.min(3, events.length); i++) {
      const event = events[i];
      for (let j = 0; j < Math.min(3, students.length); j++) {
        const student = students[j];
        const reg = {
          user: student._id,
          event: event._id,
          ticketId: 'TKT-' + Math.random().toString(36).substr(2, 8).toUpperCase(),
          status: 'registered'
        };
        reg.qrPayload = JSON.stringify({ ticketId: reg.ticketId, userId: student._id, eventId: event._id });
        try {
          reg.qrData = await QRCode.toDataURL(reg.qrPayload, {
            width: 200, margin: 2,
            color: { dark: '#1a1a2e', light: '#ffffff' }
          });
        } catch (e) {
          reg.qrData = '';
        }
        regsToCreate.push(reg);
      }
    }

    // Attended registrations for ended event
    const endedEvent = events.find(e => e.status === 'ended');
    if (endedEvent) {
      for (let j = 0; j < Math.min(3, students.length); j++) {
        const student = students[j];
        const ticketId = 'TKT-' + Math.random().toString(36).substr(2, 8).toUpperCase();
        const qrPayload = JSON.stringify({ ticketId, userId: student._id, eventId: endedEvent._id });
        let qrData = '';
        try {
          qrData = await QRCode.toDataURL(qrPayload, { width: 200, margin: 2 });
        } catch (e) {}
        regsToCreate.push({
          user: student._id,
          event: endedEvent._id,
          ticketId,
          qrPayload,
          qrData,
          status: 'attended',
          attendedAt: new Date(endedEvent.date.getTime() + 2 * 60 * 60 * 1000),
          certificateIssued: true
        });
      }
    }

    // Insert registrations (ignore duplicates)
    let inserted = 0;
    for (const reg of regsToCreate) {
      try {
        await Registration.create(reg);
        inserted++;
      } catch (e) {
        // Skip duplicates
      }
    }
    console.log(`🎫 ${inserted} registrations created`);

    console.log('\n✅ Seed complete!\n');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━');
    console.log('🔑 Admin Login:');
    console.log('   Email:    admin@eventflow.com');
    console.log('   Password: admin123');
    console.log('');
    console.log('🎓 Student Login:');
    console.log('   Email:    student@eventflow.com');
    console.log('   Password: student123');
    console.log('');
    console.log('   Or any student:');
    console.log('   Email:    rahul@college.edu');
    console.log('   Password: student123');
    console.log('━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n');

    process.exit(0);
  } catch (err) {
    console.error('❌ Seed error:', err);
    process.exit(1);
  }
}

seed();
