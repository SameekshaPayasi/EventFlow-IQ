const express = require('express');
const mongoose = require('mongoose');
const session = require('express-session');
const flash = require('connect-flash');
const methodOverride = require('method-override');
const path = require('path');

const app = express();

// ── Connect MongoDB ──
mongoose.connect(process.env.MONGO_URI || 'mongodb://localhost:27017/eventflow')
  .then(() => console.log('✅ MongoDB connected'))
  .catch(err => console.error('❌ MongoDB error:', err));

// ── View Engine ──
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// ── Middleware ──
app.use(express.urlencoded({ extended: true }));
app.use(express.json());
app.use(methodOverride('_method'));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET || 'eventflow-secret-2024',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

app.use(flash());

// ── Global locals ──
app.use((req, res, next) => {
  res.locals.currentUser   = req.session.user || null;
  res.locals.success_msg   = req.flash('success');
  res.locals.error_msg     = req.flash('error');
  res.locals.info_msg      = req.flash('info');
  next();
});

// ── Routes ──
app.use('/',         require('./routes/index'));
app.use('/auth',     require('./routes/auth'));
app.use('/events',   require('./routes/events'));
app.use('/admin',    require('./routes/admin'));
app.use('/student',  require('./routes/student'));
app.use('/scan',     require('./routes/scanner'));
app.use('/cert',     require('./routes/certificate'));

// ── 404 ──
app.use((req, res) => {
  res.status(404).render('404', { title: 'Page Not Found' });
});

// ── Error handler ──
app.use((err, req, res, next) => {
  console.error(err.stack);
  res.status(500).render('error', { title: 'Server Error', message: err.message });
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`🚀 EventFlow running on http://localhost:${PORT}`));
